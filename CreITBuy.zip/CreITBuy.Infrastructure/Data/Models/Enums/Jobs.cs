﻿namespace CreITBuy.Infrastructure.Data.Models.Enums
{
    public enum Jobs
    {
        Artist,
        Developer,
        Writer,
        Producer,
        Photographer,
        Client
    }
}
