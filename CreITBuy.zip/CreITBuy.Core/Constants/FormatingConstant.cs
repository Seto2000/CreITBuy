﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CreITBuy.Core.Constants
{
    public class FormatingConstant
    {
        public const string NormalDateFormat = "dd.MM.yyyy";
    }
}
