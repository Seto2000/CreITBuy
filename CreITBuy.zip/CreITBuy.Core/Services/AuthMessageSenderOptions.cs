﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CreITBuy.Core.Services
{
    public class AuthMessageSenderOptions
    {
        public string? SendGridKey { get; set; } = "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";
    }
}

